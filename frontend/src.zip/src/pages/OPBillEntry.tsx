import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { Save, Trash2, X, Printer, Search } from 'lucide-react'
import toast from 'react-hot-toast'
import { format } from 'date-fns'

interface BillItem {
  particular: string
  doctor: string
  department: string
  unit: number
  rate: number
  discount_percent: number
  discount_amount: number
  total: number
}

interface Doctor {
  id: number
  name: string
}

interface Patient {
  id: number
  name: string
  house: string
  street: string
  place: string
  age: string
  gender: string
  op_number: string
  ip_number?: string
}

const OPBillEntry = () => {
  const navigate = useNavigate()
  const [currentTime] = useState(new Date())
  const [patients, setPatients] = useState<Patient[]>([])
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showPatientSearch, setShowPatientSearch] = useState(false)
  
  const [formData, setFormData] = useState({
    patient_id: 0,
    op_number: '',
    ip_number: '',
    bill_type: 'Cash',
    category: 'General',
    doctor_id: 0,
    discount_type: 'None'
  })
  
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null)
  const [billItems, setBillItems] = useState<BillItem[]>([
    {
      particular: 'Consultation',
      doctor: '',
      department: '',
      unit: 1,
      rate: 0,
      discount_percent: 0,
      discount_amount: 0,
      total: 0
    }
  ])

  useEffect(() => {
    fetchDoctors()
    fetchPatients()
  }, [])

  const fetchDoctors = async () => {
    try {
      const response = await axios.get('/doctors')
      setDoctors(response.data)
      if (response.data.length > 0) {
        setFormData(prev => ({ ...prev, doctor_id: response.data[0].id }))
      }
    } catch (error) {
      toast.error('Failed to load doctors')
    }
  }

  const fetchPatients = async () => {
    try {
      const response = await axios.get('/patients')
      setPatients(response.data)
    } catch (error) {
      toast.error('Failed to load patients')
    }
  }

  const generateBillNumber = () => {
    const now = new Date()
    const dateStr = format(now, 'yyyyMMdd')
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
    return `OP${dateStr}-${random}`
  }

  const handleSearchPatient = async (type: 'op' | 'ip', value: string) => {
    if (!value.trim()) {
      toast.error(`Please enter ${type === 'op' ? 'OP' : 'IP'} number`)
      return
    }

    try {
      let patient: Patient | undefined
      if (type === 'op') {
        const response = await axios.get(`/api/patients/search/op/${value}`)
        patient = response.data
      } else {
        // For IP search, we need to filter from existing patients
        patient = patients.find(p => p.ip_number === value)
      }
      
      if (patient) {
        setSelectedPatient(patient)
        setFormData(prev => ({
          ...prev,
          patient_id: patient.id,
          [type === 'op' ? 'op_number' : 'ip_number']: value
        }))
        toast.success('Patient found')
      } else {
        toast.error('Patient not found')
      }
    } catch (error) {
      toast.error('Patient not found')
    }
  }

  const handleBillItemChange = (index: number, field: keyof BillItem, value: any) => {
    const newItems = [...billItems]
    newItems[index] = { ...newItems[index], [field]: value }
    
    // Recalculate totals if rate or unit changes
    if (field === 'rate' || field === 'unit' || field === 'discount_percent') {
      const item = newItems[index]
      const amount = item.unit * item.rate
      const discount = amount * (item.discount_percent / 100)
      item.discount_amount = discount
      item.total = amount - discount
    }
    
    setBillItems(newItems)
  }

  const addBillItem = () => {
    setBillItems([
      ...billItems,
      {
        particular: '',
        doctor: '',
        department: '',
        unit: 1,
        rate: 0,
        discount_percent: 0,
        discount_amount: 0,
        total: 0
      }
    ])
  }

  const removeBillItem = (index: number) => {
    if (billItems.length > 1) {
      const newItems = billItems.filter((_, i) => i !== index)
      setBillItems(newItems)
    }
  }

  const calculateTotals = () => {
    const totalAmount = billItems.reduce((sum, item) => sum + (item.unit * item.rate), 0)
    const totalDiscount = billItems.reduce((sum, item) => sum + item.discount_amount, 0)
    const netAmount = totalAmount - totalDiscount
    
    return { totalAmount, totalDiscount, netAmount }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!selectedPatient) {
      toast.error('Please select a patient')
      return
    }
    
    if (!formData.doctor_id) {
      toast.error('Please select a doctor')
      return
    }
    
    const { totalAmount, totalDiscount, netAmount } = calculateTotals()
    
    if (netAmount <= 0) {
      toast.error('Total amount must be greater than 0')
      return
    }
    
    setIsLoading(true)
    
    try {
      const billData = {
        patient_id: selectedPatient.id,
        bill_type: formData.bill_type,
        category: formData.category,
        doctor_id: formData.doctor_id,
        discount_type: formData.discount_type,
        items: billItems.map(item => ({
          particular: item.particular,
          doctor: item.doctor,
          department: item.department,
          unit: item.unit,
          rate: item.rate,
          discount_percent: item.discount_percent
        }))
      }
      
      const response = await axios.post('/bills/op', billData)
      toast.success(`OP Bill created: ${response.data.bill_number}`)
      
      // Reset form
      setFormData({
        patient_id: 0,
        op_number: '',
        ip_number: '',
        bill_type: 'Cash',
        category: 'General',
        doctor_id: doctors[0]?.id || 0,
        discount_type: 'None'
      })
      setSelectedPatient(null)
      setBillItems([{
        particular: 'Consultation',
        doctor: '',
        department: '',
        unit: 1,
        rate: 0,
        discount_percent: 0,
        discount_amount: 0,
        total: 0
      }])
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to create bill')
    } finally {
      setIsLoading(false)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to clear this bill?')) {
      setFormData({
        patient_id: 0,
        op_number: '',
        ip_number: '',
        bill_type: 'Cash',
        category: 'General',
        doctor_id: doctors[0]?.id || 0,
        discount_type: 'None'
      })
      setSelectedPatient(null)
      setBillItems([{
        particular: 'Consultation',
        doctor: '',
        department: '',
        unit: 1,
        rate: 0,
        discount_percent: 0,
        discount_amount: 0,
        total: 0
      }])
      toast.success('Bill cleared')
    }
  }

  const { totalAmount, totalDiscount, netAmount } = calculateTotals()

  return (
    <div className="max-w-7xl mx-auto">
      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">OP Bill Entry</h1>
          <button
            onClick={() => navigate('/dashboard')}
            className="btn-secondary"
          >
            <X size={20} className="mr-2" />
            Close
          </button>
        </div>

        {/* Header Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Bill No.
            </label>
            <input
              type="text"
              value={generateBillNumber()}
              className="input-field bg-gray-100"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date
            </label>
            <input
              type="text"
              value={format(new Date(), 'dd/MM/yyyy')}
              className="input-field bg-gray-100"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Time
            </label>
            <input
              type="text"
              value={format(currentTime, 'HH:mm:ss')}
              className="input-field bg-gray-100"
              readOnly
            />
          </div>
        </div>

        {/* Patient Search Section */}
        <div className="mb-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                OP Number
              </label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={formData.op_number}
                  onChange={(e) => setFormData({ ...formData, op_number: e.target.value })}
                  className="input-field"
                  placeholder="Enter OP number"
                />
                <button
                  type="button"
                  onClick={() => handleSearchPatient('op', formData.op_number)}
                  className="btn-primary flex items-center"
                >
                  <Search size={20} />
                </button>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                IP Number
              </label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={formData.ip_number}
                  onChange={(e) => setFormData({ ...formData, ip_number: e.target.value })}
                  className="input-field"
                  placeholder="Enter IP number"
                />
                <button
                  type="button"
                  onClick={() => handleSearchPatient('ip', formData.ip_number)}
                  className="btn-primary flex items-center"
                >
                  <Search size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Patient Details */}
        {selectedPatient && (
          <div className="mb-6 p-4 bg-blue-50 rounded-lg">
            <h3 className="font-semibold mb-3">Patient Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm text-gray-600">Name</label>
                <p className="font-medium">{selectedPatient.name}</p>
              </div>
              <div>
                <label className="text-sm text-gray-600">Age/Gender</label>
                <p className="font-medium">{selectedPatient.age} / {selectedPatient.gender}</p>
              </div>
              <div>
                <label className="text-sm text-gray-600">Address</label>
                <p className="font-medium">
                  {[selectedPatient.house, selectedPatient.street, selectedPatient.place]
                    .filter(Boolean).join(', ')}
                </p>
              </div>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Bill Type and Category */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Bill Type *
              </label>
              <select
                value={formData.bill_type}
                onChange={(e) => setFormData({ ...formData, bill_type: e.target.value })}
                className="input-field"
                required
              >
                <option value="Cash">Cash</option>
                <option value="Card">Card</option>
                <option value="UPI">UPI</option>
                <option value="Cheque">Cheque</option>
                <option value="Insurance">Insurance</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="input-field"
                required
              >
                <option value="General">General</option>
                <option value="Emergency">Emergency</option>
                <option value="Follow-up">Follow-up</option>
                <option value="Review">Review</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Doctor *
              </label>
              <select
                value={formData.doctor_id}
                onChange={(e) => setFormData({ ...formData, doctor_id: parseInt(e.target.value) })}
                className="input-field"
                required
              >
                <option value="">Select Doctor</option>
                {doctors.map((doctor) => (
                  <option key={doctor.id} value={doctor.id}>
                    {doctor.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Discount Type
              </label>
              <select
                value={formData.discount_type}
                onChange={(e) => setFormData({ ...formData, discount_type: e.target.value })}
                className="input-field"
              >
                <option value="None">None</option>
                <option value="Senior Citizen">Senior Citizen</option>
                <option value="Staff">Staff</option>
                <option value="Insurance">Insurance</option>
                <option value="Special">Special</option>
              </select>
            </div>
          </div>

          {/* Bill Items Table */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Bill Items</h3>
              <button
                type="button"
                onClick={addBillItem}
                className="text-sm btn-primary"
              >
                Add Item
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">SL No</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Particular</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Doctor</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dept</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Unit</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rate</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Disc %</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Disc Amt</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {billItems.map((item, index) => (
                    <tr key={index}>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={index + 1}
                          className="input-field w-16 text-center bg-gray-100"
                          readOnly
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.particular}
                          onChange={(e) => handleBillItemChange(index, 'particular', e.target.value)}
                          className="input-field"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.doctor}
                          onChange={(e) => handleBillItemChange(index, 'doctor', e.target.value)}
                          className="input-field"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.department}
                          onChange={(e) => handleBillItemChange(index, 'department', e.target.value)}
                          className="input-field"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="number"
                          value={item.unit}
                          onChange={(e) => handleBillItemChange(index, 'unit', parseInt(e.target.value) || 0)}
                          className="input-field w-20"
                          min="1"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="number"
                          step="0.01"
                          value={item.rate}
                          onChange={(e) => handleBillItemChange(index, 'rate', parseFloat(e.target.value) || 0)}
                          className="input-field w-24"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={(item.unit * item.rate).toFixed(2)}
                          className="input-field w-24 bg-gray-100"
                          readOnly
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="number"
                          step="0.01"
                          value={item.discount_percent}
                          onChange={(e) => handleBillItemChange(index, 'discount_percent', parseFloat(e.target.value) || 0)}
                          className="input-field w-20"
                          max="100"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.discount_amount.toFixed(2)}
                          className="input-field w-24 bg-gray-100"
                          readOnly
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.total.toFixed(2)}
                          className="input-field w-24 bg-gray-100"
                          readOnly
                        />
                      </td>
                      <td className="px-4 py-2">
                        {billItems.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeBillItem(index)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Totals Section */}
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between">
                <span className="font-medium">Total Amount:</span>
                <span className="font-bold">₹{totalAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Discount:</span>
                <span className="font-bold text-red-600">₹{totalDiscount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-t pt-2">
                <span className="font-medium">Net Amount:</span>
                <span className="font-bold text-green-600">₹{netAmount.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Footer Section */}
          <div className="flex items-center justify-between pt-6 border-t">
            <div className="text-sm text-gray-600">
              Logged in as: <span className="font-semibold">Admin User</span>
            </div>
            
            <div className="flex space-x-3">
              <button
                type="button"
                onClick={handleDelete}
                className="btn-danger flex items-center"
              >
                <Trash2 size={20} className="mr-2" />
                Delete
              </button>
              
              <button
                type="button"
                onClick={handlePrint}
                className="btn-secondary flex items-center"
              >
                <Printer size={20} className="mr-2" />
                Print
              </button>
              
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="btn-secondary flex items-center"
              >
                <X size={20} className="mr-2" />
                Cancel
              </button>
              
              <button
                type="submit"
                disabled={isLoading}
                className="btn-primary flex items-center"
              >
                <Save size={20} className="mr-2" />
                {isLoading ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

export default OPBillEntry