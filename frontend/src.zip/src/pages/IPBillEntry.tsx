import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { Save, Trash2, X, Printer, Search } from 'lucide-react'
import toast from 'react-hot-toast'
import { format } from 'date-fns'

interface BillItem {
  particular: string
  department: string
  amount: number
  discount_percent: number
  discount_amount: number
  total: number
}

interface Doctor {
  id: number
  name: string
}

interface Patient {
  id: number
  name: string
  house: string
  street: string
  place: string
  age: string
  gender: string
  ip_number: string
  room: string
}

const IPBillEntry = () => {
  const navigate = useNavigate()
  const [currentTime] = useState(new Date())
  const [patients, setPatients] = useState<Patient[]>([])
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [isLoading, setIsLoading] = useState(false)
  
  const [formData, setFormData] = useState({
    patient_id: 0,
    ip_number: '',
    is_credit: false,
    is_insurance: false,
    category: 'General',
    doctor_id: 0,
    discount_type: 'None',
    room: '',
    admission_date: format(new Date(), 'yyyy-MM-dd'),
    insurance_company: '',
    third_party: '',
    service_tax: 0,
    education_cess: 0,
    she_education_cess: 0
  })
  
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null)
  const [billItems, setBillItems] = useState<BillItem[]>([
    {
      particular: 'Room Charges',
      department: 'General',
      amount: 0,
      discount_percent: 0,
      discount_amount: 0,
      total: 0
    }
  ])

  useEffect(() => {
    fetchDoctors()
    fetchPatients()
  }, [])

  const fetchDoctors = async () => {
    try {
      const response = await axios.get('/doctors')
      setDoctors(response.data)
      if (response.data.length > 0) {
        setFormData(prev => ({ ...prev, doctor_id: response.data[0].id }))
      }
    } catch (error) {
      toast.error('Failed to load doctors')
    }
  }

  const fetchPatients = async () => {
    try {
      const response = await axios.get('/patients', { params: { is_ip: true } })
      setPatients(response.data)
    } catch (error) {
      toast.error('Failed to load patients')
    }
  }

  const generateBillNumber = () => {
    const now = new Date()
    const dateStr = format(now, 'yyyyMMdd')
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
    return `IP${dateStr}-${random}`
  }

  const handleSearchPatient = async (ipNumber: string) => {
    if (!ipNumber.trim()) {
      toast.error('Please enter IP number')
      return
    }

    try {
      const patient = patients.find(p => p.ip_number === ipNumber)
      
      if (patient) {
        setSelectedPatient(patient)
        setFormData(prev => ({
          ...prev,
          patient_id: patient.id,
          ip_number: patient.ip_number,
          room: patient.room || ''
        }))
        toast.success('Patient found')
      } else {
        toast.error('Patient not found')
      }
    } catch (error) {
      toast.error('Patient not found')
    }
  }

  const handleBillItemChange = (index: number, field: keyof BillItem, value: any) => {
    const newItems = [...billItems]
    newItems[index] = { ...newItems[index], [field]: value }
    
    // Recalculate totals if amount or discount changes
    if (field === 'amount' || field === 'discount_percent') {
      const item = newItems[index]
      const discount = item.amount * (item.discount_percent / 100)
      item.discount_amount = discount
      item.total = item.amount - discount
    }
    
    setBillItems(newItems)
  }

  const addBillItem = () => {
    setBillItems([
      ...billItems,
      {
        particular: '',
        department: 'General',
        amount: 0,
        discount_percent: 0,
        discount_amount: 0,
        total: 0
      }
    ])
  }

  const removeBillItem = (index: number) => {
    if (billItems.length > 1) {
      const newItems = billItems.filter((_, i) => i !== index)
      setBillItems(newItems)
    }
  }

  const calculateTotals = () => {
    const totalAmount = billItems.reduce((sum, item) => sum + item.amount, 0)
    const totalDiscount = billItems.reduce((sum, item) => sum + item.discount_amount, 0)
    const subTotal = totalAmount - totalDiscount
    const netAmount = subTotal + formData.service_tax + formData.education_cess + formData.she_education_cess
    
    return { totalAmount, totalDiscount, subTotal, netAmount }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!selectedPatient) {
      toast.error('Please select a patient')
      return
    }
    
    if (!formData.doctor_id) {
      toast.error('Please select a doctor')
      return
    }
    
    const { netAmount } = calculateTotals()
    
    if (netAmount <= 0) {
      toast.error('Total amount must be greater than 0')
      return
    }
    
    setIsLoading(true)
    
    try {
      const billData = {
        patient_id: selectedPatient.id,
        is_credit: formData.is_credit,
        is_insurance: formData.is_insurance,
        category: formData.category,
        doctor_id: formData.doctor_id,
        discount_type: formData.discount_type,
        room: formData.room,
        admission_date: new Date(formData.admission_date).toISOString(),
        insurance_company: formData.insurance_company || null,
        third_party: formData.third_party || null,
        service_tax: formData.service_tax,
        education_cess: formData.education_cess,
        she_education_cess: formData.she_education_cess,
        items: billItems.map(item => ({
          particular: item.particular,
          department: item.department,
          amount: item.amount,
          discount_percent: item.discount_percent
        }))
      }
      
      const response = await axios.post('/bills/ip', billData)
      toast.success(`IP Bill created: ${response.data.bill_number}`)
      
      // Reset form
      setFormData({
        patient_id: 0,
        ip_number: '',
        is_credit: false,
        is_insurance: false,
        category: 'General',
        doctor_id: doctors[0]?.id || 0,
        discount_type: 'None',
        room: '',
        admission_date: format(new Date(), 'yyyy-MM-dd'),
        insurance_company: '',
        third_party: '',
        service_tax: 0,
        education_cess: 0,
        she_education_cess: 0
      })
      setSelectedPatient(null)
      setBillItems([{
        particular: 'Room Charges',
        department: 'General',
        amount: 0,
        discount_percent: 0,
        discount_amount: 0,
        total: 0
      }])
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to create bill')
    } finally {
      setIsLoading(false)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to clear this bill?')) {
      setFormData({
        patient_id: 0,
        ip_number: '',
        is_credit: false,
        is_insurance: false,
        category: 'General',
        doctor_id: doctors[0]?.id || 0,
        discount_type: 'None',
        room: '',
        admission_date: format(new Date(), 'yyyy-MM-dd'),
        insurance_company: '',
        third_party: '',
        service_tax: 0,
        education_cess: 0,
        she_education_cess: 0
      })
      setSelectedPatient(null)
      setBillItems([{
        particular: 'Room Charges',
        department: 'General',
        amount: 0,
        discount_percent: 0,
        discount_amount: 0,
        total: 0
      }])
      toast.success('Bill cleared')
    }
  }

  const { totalAmount, totalDiscount, netAmount } = calculateTotals()

  return (
    <div className="max-w-7xl mx-auto">
      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">IP Bill Entry</h1>
          <button
            onClick={() => navigate('/dashboard')}
            className="btn-secondary"
          >
            <X size={20} className="mr-2" />
            Close
          </button>
        </div>

        {/* Header Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Bill No.
            </label>
            <input
              type="text"
              value={generateBillNumber()}
              className="input-field bg-gray-100"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date
            </label>
            <input
              type="text"
              value={format(new Date(), 'dd/MM/yyyy')}
              className="input-field bg-gray-100"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Time
            </label>
            <input
              type="text"
              value={format(currentTime, 'HH:mm:ss')}
              className="input-field bg-gray-100"
              readOnly
            />
          </div>
        </div>

        {/* IP Number Search */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            IP Number *
          </label>
          <div className="flex space-x-2">
            <input
              type="text"
              value={formData.ip_number}
              onChange={(e) => setFormData({ ...formData, ip_number: e.target.value })}
              className="input-field"
              placeholder="Enter IP number"
            />
            <button
              type="button"
              onClick={() => handleSearchPatient(formData.ip_number)}
              className="btn-primary flex items-center"
            >
              <Search size={20} />
            </button>
          </div>
        </div>

        {/* Patient Details */}
        {selectedPatient && (
          <div className="mb-6 p-4 bg-blue-50 rounded-lg">
            <h3 className="font-semibold mb-3">Patient Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm text-gray-600">Name</label>
                <p className="font-medium">{selectedPatient.name}</p>
              </div>
              <div>
                <label className="text-sm text-gray-600">Age/Gender</label>
                <p className="font-medium">{selectedPatient.age} / {selectedPatient.gender}</p>
              </div>
              <div>
                <label className="text-sm text-gray-600">Room</label>
                <p className="font-medium">{selectedPatient.room || 'Not assigned'}</p>
              </div>
              <div className="md:col-span-3">
                <label className="text-sm text-gray-600">Address</label>
                <p className="font-medium">
                  {[selectedPatient.house, selectedPatient.street, selectedPatient.place]
                    .filter(Boolean).join(', ')}
                </p>
              </div>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Bill Options */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.is_credit}
                  onChange={(e) => setFormData({ ...formData, is_credit: e.target.checked })}
                  className="mr-2"
                />
                <span>Credit</span>
              </label>
              
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.is_insurance}
                  onChange={(e) => setFormData({ ...formData, is_insurance: e.target.checked })}
                  className="mr-2"
                />
                <span>Insurance</span>
              </label>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="input-field"
                required
              >
                <option value="General">General</option>
                <option value="Emergency">Emergency</option>
                <option value="ICU">ICU</option>
                <option value="Surgery">Surgery</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Doctor *
              </label>
              <select
                value={formData.doctor_id}
                onChange={(e) => setFormData({ ...formData, doctor_id: parseInt(e.target.value) })}
                className="input-field"
                required
              >
                <option value="">Select Doctor</option>
                {doctors.map((doctor) => (
                  <option key={doctor.id} value={doctor.id}>
                    {doctor.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Discount Type
              </label>
              <select
                value={formData.discount_type}
                onChange={(e) => setFormData({ ...formData, discount_type: e.target.value })}
                className="input-field"
              >
                <option value="None">None</option>
                <option value="Senior Citizen">Senior Citizen</option>
                <option value="Insurance">Insurance</option>
                <option value="Staff">Staff</option>
              </select>
            </div>
          </div>

          {/* Room and Admission Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Room
              </label>
              <input
                type="text"
                value={formData.room}
                onChange={(e) => setFormData({ ...formData, room: e.target.value })}
                className="input-field"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Admission Date
              </label>
              <input
                type="date"
                value={formData.admission_date}
                onChange={(e) => setFormData({ ...formData, admission_date: e.target.value })}
                className="input-field"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Admission Time
              </label>
              <input
                type="time"
                value={format(currentTime, 'HH:mm')}
                className="input-field bg-gray-100"
                readOnly
              />
            </div>
          </div>

          {/* Insurance Details (if insurance is checked) */}
          {formData.is_insurance && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-yellow-50 rounded-lg">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Insurance Company
                </label>
                <input
                  type="text"
                  value={formData.insurance_company}
                  onChange={(e) => setFormData({ ...formData, insurance_company: e.target.value })}
                  className="input-field"
                  placeholder="Enter insurance company"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Third Party
                </label>
                <input
                  type="text"
                  value={formData.third_party}
                  onChange={(e) => setFormData({ ...formData, third_party: e.target.value })}
                  className="input-field"
                  placeholder="Enter third party details"
                />
              </div>
            </div>
          )}

          {/* Bill Items Table */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Bill Items</h3>
              <button
                type="button"
                onClick={addBillItem}
                className="text-sm btn-primary"
              >
                Add Item
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">SL No</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Particular</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Disc %</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Disc Amt</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {billItems.map((item, index) => (
                    <tr key={index}>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={index + 1}
                          className="input-field w-16 text-center bg-gray-100"
                          readOnly
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.particular}
                          onChange={(e) => handleBillItemChange(index, 'particular', e.target.value)}
                          className="input-field"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.department}
                          onChange={(e) => handleBillItemChange(index, 'department', e.target.value)}
                          className="input-field"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="number"
                          step="0.01"
                          value={item.amount}
                          onChange={(e) => handleBillItemChange(index, 'amount', parseFloat(e.target.value) || 0)}
                          className="input-field w-24"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="number"
                          step="0.01"
                          value={item.discount_percent}
                          onChange={(e) => handleBillItemChange(index, 'discount_percent', parseFloat(e.target.value) || 0)}
                          className="input-field w-20"
                          max="100"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.discount_amount.toFixed(2)}
                          className="input-field w-24 bg-gray-100"
                          readOnly
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="text"
                          value={item.total.toFixed(2)}
                          className="input-field w-24 bg-gray-100"
                          readOnly
                        />
                      </td>
                      <td className="px-4 py-2">
                        {billItems.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeBillItem(index)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Tax and Cess Details */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Service Tax
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.service_tax}
                onChange={(e) => setFormData({ ...formData, service_tax: parseFloat(e.target.value) || 0 })}
                className="input-field"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Education Cess (+)
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.education_cess}
                onChange={(e) => setFormData({ ...formData, education_cess: parseFloat(e.target.value) || 0 })}
                className="input-field"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                SH Education Cess (+)
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.she_education_cess}
                onChange={(e) => setFormData({ ...formData, she_education_cess: parseFloat(e.target.value) || 0 })}
                className="input-field"
              />
            </div>
          </div>

          {/* Totals Section */}
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between">
                <span className="font-medium">Total Amount:</span>
                <span className="font-bold">₹{totalAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Discount:</span>
                <span className="font-bold text-red-600">₹{totalDiscount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Service Tax:</span>
                <span className="font-bold">₹{formData.service_tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Education Cess:</span>
                <span className="font-bold">₹{formData.education_cess.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">SH Education Cess:</span>
                <span className="font-bold">₹{formData.she_education_cess.toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-t pt-2">
                <span className="font-medium">Net Amount:</span>
                <span className="font-bold text-green-600">₹{netAmount.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Footer Section */}
          <div className="flex items-center justify-between pt-6 border-t">
            <div className="text-sm text-gray-600">
              Logged in as: <span className="font-semibold">Admin User</span>
            </div>
            
            <div className="flex space-x-3">
              <button
                type="button"
                onClick={handleDelete}
                className="btn-danger flex items-center"
              >
                <Trash2 size={20} className="mr-2" />
                Delete
              </button>
              
              <button
                type="button"
                onClick={handlePrint}
                className="btn-secondary flex items-center"
              >
                <Printer size={20} className="mr-2" />
                Print
              </button>
              
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="btn-secondary flex items-center"
              >
                <X size={20} className="mr-2" />
                Cancel
              </button>
              
              <button
                type="submit"
                disabled={isLoading}
                className="btn-primary flex items-center"
              >
                <Save size={20} className="mr-2" />
                {isLoading ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

export default IPBillEntry