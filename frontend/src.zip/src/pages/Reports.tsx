import { useState, useEffect } from 'react'
import axios from 'axios'
import { Download, Filter, Calendar, Printer, FileText } from 'lucide-react'
import toast from 'react-hot-toast'
import { format } from 'date-fns'

const Reports = () => {
  const [activeReport, setActiveReport] = useState('daily-op')
  const [isLoading, setIsLoading] = useState(false)
  const [reportData, setReportData] = useState<any>(null)
  
  // Filters
  const [startDate, setStartDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [doctorId, setDoctorId] = useState('')

  const reportTypes = [
    { id: 'daily-op', label: 'Daily OP Report', icon: FileText },
    { id: 'bill-summary', label: 'Bill Summary', icon: FileText },
    { id: 'patient-list', label: 'Patient List', icon: FileText },
    { id: 'appointment-list', label: 'Appointment List', icon: Calendar }
  ]

  const fetchReport = async () => {
    setIsLoading(true)
    try {
      let response
      
      switch (activeReport) {
        case 'daily-op':
          response = await axios.get('/reports/daily-op', {
            params: { report_date: startDate }
          })
          break
        
        case 'bill-summary':
          response = await axios.get('/reports/bill-summary', {
            params: { start_date: startDate, end_date: endDate }
          })
          break
        
        case 'patient-list':
          response = await axios.get('/reports/patient-list', {
            params: { start_date: startDate, end_date: endDate }
          })
          break
        
        case 'appointment-list':
          response = await axios.get('/reports/appointment-list', {
            params: { appointment_date: startDate, doctor_id: doctorId || undefined }
          })
          break
        
        default:
          response = await axios.get('/reports/daily-op')
      }
      
      setReportData(response.data)
    } catch (error) {
      toast.error('Failed to fetch report')
      setReportData(null)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchReport()
  }, [activeReport, startDate, endDate, doctorId])

  const handlePrint = () => {
    window.print()
  }

  const handleExport = () => {
    if (!reportData) return
    
    const dataStr = JSON.stringify(reportData, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${activeReport}-${format(new Date(), 'yyyy-MM-dd')}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const renderReportContent = () => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      )
    }

    if (!reportData) {
      return (
        <div className="text-center py-12">
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">No data available</p>
        </div>
      )
    }

    switch (activeReport) {
      case 'daily-op':
        return (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Bill No</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Patient</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Doctor</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Bill Type</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Discount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Net</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {Array.isArray(reportData) && reportData.map((bill: any) => (
                  <tr key={bill.id}>
                    <td className="px-6 py-4 whitespace-nowrap">{bill.bill_number}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{bill.patient?.name || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{bill.doctor?.name || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{bill.bill_type}</td>
                    <td className="px-6 py-4 whitespace-nowrap">₹{bill.total_amount?.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap">₹{bill.discount_amount?.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap">₹{bill.net_amount?.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )

      case 'bill-summary':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="card">
                <h3 className="font-semibold mb-2">OP Bills Summary</h3>
                <p className="text-2xl font-bold">₹{reportData?.total_op_amount?.toFixed(2) || '0.00'}</p>
                <p className="text-sm text-gray-600">{reportData?.op_bills?.length || 0} bills</p>
              </div>
              <div className="card">
                <h3 className="font-semibold mb-2">IP Bills Summary</h3>
                <p className="text-2xl font-bold">₹{reportData?.total_ip_amount?.toFixed(2) || '0.00'}</p>
                <p className="text-sm text-gray-600">{reportData?.ip_bills?.length || 0} bills</p>
              </div>
              <div className="card">
                <h3 className="font-semibold mb-2">Total Revenue</h3>
                <p className="text-2xl font-bold text-green-600">
                  ₹{reportData?.total_amount?.toFixed(2) || '0.00'}
                </p>
                <p className="text-sm text-gray-600">Combined total</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Bill No</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Patient</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Net Amount</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {[
                    ...(reportData?.op_bills || []),
                    ...(reportData?.ip_bills || [])
                  ].map((bill: any) => (
                    <tr key={bill.id}>
                      <td className="px-6 py-4 whitespace-nowrap">{bill.bill_number}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          bill.bill_number?.startsWith('OP') 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {bill.bill_number?.startsWith('OP') ? 'OP' : 'IP'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">{bill.patient?.name || 'N/A'}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {format(new Date(bill.bill_date), 'dd/MM/yyyy')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">₹{bill.net_amount?.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )

      case 'patient-list':
        return (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">OP/IP No</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Age</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Gender</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Place</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Registration Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {Array.isArray(reportData) && reportData.map((patient: any) => (
                  <tr key={patient.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {patient.is_ip ? patient.ip_number : patient.op_number}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{patient.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{patient.age}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{patient.gender}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{patient.phone}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{patient.place}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {format(new Date(patient.registration_date), 'dd/MM/yyyy')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        patient.is_ip 
                          ? 'bg-purple-100 text-purple-800' 
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {patient.is_ip ? 'IP' : 'OP'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )

      case 'appointment-list':
        return (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Token No</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Patient</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Doctor</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Speciality</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray500 uppercase">Time</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Notes</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {Array.isArray(reportData) && reportData.map((appointment: any) => (
                  <tr key={appointment.id}>
                    <td className="px-6 py-4 whitespace-nowrap">{appointment.token_number}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="font-medium">{appointment.patient_name}</div>
                        <div className="text-sm text-gray-600">{appointment.patient_phone}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="font-medium">{appointment.doctor_name}</div>
                        <div className="text-sm text-gray-600">{appointment.doctor_specialty}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{appointment.doctor_specialty}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {format(new Date(appointment.appointment_date), 'hh:mm a')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        appointment.status === 'Scheduled' 
                          ? 'bg-yellow-100 text-yellow-800'
                          : appointment.status === 'Completed'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {appointment.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{appointment.notes || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="card">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
          <p className="text-gray-600">Generate and view system reports</p>
        </div>

        {/* Report Type Tabs */}
        <div className="mb-6">
          <div className="flex space-x-2 overflow-x-auto pb-2">
            {reportTypes.map((report) => {
              const Icon = report.icon
              const isActive = activeReport === report.id
              
              return (
                <button
                  key={report.id}
                  onClick={() => setActiveReport(report.id)}
                  className={`flex items-center space-x-2 px-4 py-3 rounded-lg whitespace-nowrap transition-colors ${
                    isActive
                      ? 'bg-primary-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Icon size={20} />
                  <span className="font-medium">{report.label}</span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Report Filters */}
        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center mb-4">
            <Filter size={20} className="mr-2" />
            <h3 className="font-semibold">Filters</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="input-field"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                End Date
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="input-field"
              />
            </div>
            
            {activeReport === 'appointment-list' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Doctor (Optional)
                </label>
                <input
                  type="text"
                  value={doctorId}
                  onChange={(e) => setDoctorId(e.target.value)}
                  placeholder="Enter doctor ID"
                  className="input-field"
                />
              </div>
            )}
          </div>
          
          <div className="flex justify-end space-x-3 mt-4">
            <button
              onClick={fetchReport}
              disabled={isLoading}
              className="btn-primary"
            >
              {isLoading ? 'Loading...' : 'Apply Filters'}
            </button>
          </div>
        </div>

        {/* Report Actions */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-semibold">
              {reportTypes.find(r => r.id === activeReport)?.label}
            </h3>
            <p className="text-sm text-gray-600">
              Generated on {format(new Date(), 'dd/MM/yyyy hh:mm a')}
            </p>
          </div>
          
          <div className="flex space-x-3">
            <button
              onClick={handleExport}
              disabled={!reportData || isLoading}
              className="btn-secondary flex items-center"
            >
              <Download size={20} className="mr-2" />
              Export
            </button>
            
            <button
              onClick={handlePrint}
              disabled={!reportData || isLoading}
              className="btn-secondary flex items-center"
            >
              <Printer size={20} className="mr-2" />
              Print
            </button>
          </div>
        </div>

        {/* Report Content */}
        <div className="border rounded-lg">
          {renderReportContent()}
        </div>

        {/* Summary Footer */}
        {reportData && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Records:</p>
                <p className="font-semibold">
                  {Array.isArray(reportData) 
                    ? reportData.length 
                    : (reportData.op_bills?.length || 0) + (reportData.ip_bills?.length || 0)
                  }
                </p>
              </div>
              
              {(activeReport === 'daily-op' || activeReport === 'bill-summary') && (
                <div className="text-right">
                  <p className="text-sm text-gray-600">Total Amount:</p>
                  <p className="text-2xl font-bold text-green-600">
                    ₹{(
                      activeReport === 'daily-op'
                        ? reportData.reduce((sum: number, bill: any) => sum + (bill.net_amount || 0), 0)
                        : reportData.total_amount || 0
                    ).toFixed(2)}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Reports