import { useState, useEffect } from 'react'
import axios from 'axios'
import { 
  Users, 
  UserPlus, 
  FileText, 
  ClipboardList, 
  Calendar,
  TrendingUp
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'

interface DashboardStats {
  total_patients_today: number
  total_op_bills_today: number
  total_ip_bills_today: number
  total_revenue_today: number
  pending_appointments: number
}

const Dashboard = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    fetchDashboardStats()
  }, [])

  const fetchDashboardStats = async () => {
    try {
      const response = await axios.get('/dashboard/stats')
      setStats(response.data)
    } catch (error) {
      toast.error('Failed to load dashboard stats')
    } finally {
      setIsLoading(false)
    }
  }

  const quickActions = [
    {
      title: 'OP Registration',
      description: 'Register new outpatient',
      icon: UserPlus,
      color: 'bg-blue-100 text-blue-600',
      action: () => navigate('/patient/registration?type=op')
    },
    {
      title: 'IP Registration',
      description: 'Register new inpatient',
      icon: Users,
      color: 'bg-purple-100 text-purple-600',
      action: () => navigate('/patient/registration?type=ip')
    },
    {
      title: 'OP Billing',
      description: 'Create OP bill',
      icon: FileText,
      color: 'bg-green-100 text-green-600',
      action: () => navigate('/billing/op')
    },
    {
      title: 'IP Billing',
      description: 'Create IP bill',
      icon: ClipboardList,
      color: 'bg-orange-100 text-orange-600',
      action: () => navigate('/billing/ip')
    },
    {
      title: 'Doctor Master',
      description: 'Manage doctors',
      icon: Users,
      color: 'bg-red-100 text-red-600',
      action: () => navigate('/doctor/master')
    },
    {
      title: 'Reports',
      description: 'View all reports',
      icon: TrendingUp,
      color: 'bg-indigo-100 text-indigo-600',
      action: () => navigate('/reports')
    }
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Welcome to Hospital Management System - Lite Version</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today's Patients</p>
              <p className="text-3xl font-bold mt-2">{stats?.total_patients_today || 0}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">OP Bills Today</p>
              <p className="text-3xl font-bold mt-2">{stats?.total_op_bills_today || 0}</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <FileText className="w-8 h-8 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">IP Bills Today</p>
              <p className="text-3xl font-bold mt-2">{stats?.total_ip_bills_today || 0}</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              <ClipboardList className="w-8 h-8 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today's Revenue</p>
              <p className="text-3xl font-bold mt-2">₹{stats?.total_revenue_today?.toLocaleString() || 0}</p>
            </div>
            <div className="p-3 bg-yellow-100 rounded-lg">
              <TrendingUp className="w-8 h-8 text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="card">
        <h2 className="text-xl font-semibold mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon
            return (
              <button
                key={index}
                onClick={action.action}
                className="flex items-center p-4 border border-gray-200 rounded-lg hover:border-primary-300 hover:shadow-sm transition-all"
              >
                <div className={`p-3 rounded-lg ${action.color} mr-4`}>
                  <Icon size={24} />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-900">{action.title}</h3>
                  <p className="text-sm text-gray-600">{action.description}</p>
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="text-xl font-semibold mb-4">Pending Appointments</h2>
          <div className="flex items-center justify-center h-40">
            <div className="text-center">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-3xl font-bold">{stats?.pending_appointments || 0}</p>
              <p className="text-gray-600 mt-2">Appointments pending</p>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 className="text-xl font-semibold mb-4">System Status</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Database</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded">Online</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">API Server</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded">Running</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Authentication</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded">Active</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Print Service</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded">Ready</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard