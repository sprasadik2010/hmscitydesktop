import { useState, useEffect } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import axios from 'axios'
import { Save, X, Search, Trash2 } from 'lucide-react'
import toast from 'react-hot-toast'
import { format } from 'date-fns'

interface Doctor {
  id: number
  name: string
  code: string
}

interface PatientFormData {
  name: string
  age: string
  gender: 'Male' | 'Female' | 'Other'
  complaint: string
  house: string
  street: string
  place: string
  phone: string
  doctor_id: number
  referred_by: string
  room: string
  is_ip: boolean
}

const PatientRegistration = () => {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const type = searchParams.get('type') || 'op'
  const isIP = type === 'ip'
  
  const [formData, setFormData] = useState<PatientFormData>({
    name: '',
    age: '',
    gender: 'Male',
    complaint: '',
    house: '',
    street: '',
    place: '',
    phone: '',
    doctor_id: 0,
    referred_by: '',
    room: '',
    is_ip: isIP
  })
  
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [opNumber, setOpNumber] = useState('')
  const [showPatientSearch, setShowPatientSearch] = useState(false)

  useEffect(() => {
    fetchDoctors()
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const fetchDoctors = async () => {
    try {
      const response = await axios.get('/doctors')
      setDoctors(response.data)
      if (response.data.length > 0) {
        setFormData(prev => ({ ...prev, doctor_id: response.data[0].id }))
      }
    } catch (error) {
      toast.error('Failed to load doctors')
    }
  }

  const generatePatientNumber = () => {
    const now = new Date()
    const yearMonth = format(now, 'yyyyMM')
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
    return isIP 
      ? `${yearMonth}-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`
      : `${yearMonth}-${random}`
  }

  const handleSearchOP = async () => {
    if (!opNumber.trim()) {
      toast.error('Please enter OP number')
      return
    }

    try {
      const response = await axios.get(`/api/patients/search/op/${opNumber}`)
      const patient = response.data
      
      setFormData({
        name: patient.name,
        age: patient.age,
        gender: patient.gender,
        complaint: patient.complaint,
        house: patient.house,
        street: patient.street,
        place: patient.place,
        phone: patient.phone,
        doctor_id: patient.doctor_id,
        referred_by: patient.referred_by || '',
        room: patient.room || '',
        is_ip: isIP
      })
      
      toast.success('Patient data loaded successfully')
    } catch (error) {
      toast.error('Patient not found')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.name || !formData.phone || !formData.doctor_id) {
      toast.error('Please fill required fields')
      return
    }
    
    setIsLoading(true)
    
    try {
      await axios.post('/patients', formData)
      toast.success(`Patient registered successfully as ${isIP ? 'IP' : 'OP'}`)
      
      // Reset form
      setFormData({
        name: '',
        age: '',
        gender: 'Male',
        complaint: '',
        house: '',
        street: '',
        place: '',
        phone: '',
        doctor_id: doctors[0]?.id || 0,
        referred_by: '',
        room: '',
        is_ip: isIP
      })
      setOpNumber('')
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Registration failed')
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this form?')) {
      setFormData({
        name: '',
        age: '',
        gender: 'Male',
        complaint: '',
        house: '',
        street: '',
        place: '',
        phone: '',
        doctor_id: doctors[0]?.id || 0,
        referred_by: '',
        room: '',
        is_ip: isIP
      })
      setOpNumber('')
      toast.success('Form cleared')
    }
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">
            {isIP ? 'IP Registration' : 'OP Registration'}
          </h1>
          <button
            onClick={() => navigate('/dashboard')}
            className="btn-secondary"
          >
            <X size={20} className="mr-2" />
            Close
          </button>
        </div>

        {/* Header Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {isIP ? 'IP Number' : 'OP Number'}
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={generatePatientNumber()}
                className="input-field bg-gray-100"
                readOnly
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Current Date
            </label>
            <input
              type="text"
              value={format(new Date(), 'dd/MM/yyyy')}
              className="input-field bg-gray-100"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Current Time
            </label>
            <input
              type="text"
              value={format(currentTime, 'HH:mm:ss')}
              className="input-field bg-gray-100"
              readOnly
            />
          </div>
        </div>

        {/* OP Number Search (Only for IP Registration) */}
        {isIP && (
          <div className="mb-6 p-4 bg-blue-50 rounded-lg">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Search Existing OP Patient
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={opNumber}
                onChange={(e) => setOpNumber(e.target.value)}
                placeholder="Enter OP number"
                className="input-field flex-1"
              />
              <button
                onClick={handleSearchOP}
                className="btn-primary flex items-center"
              >
                <Search size={20} />
                <span className="ml-2">Search</span>
              </button>
            </div>
          </div>
        )}

        {/* Patient Details Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="input-field"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Age *
              </label>
              <input
                type="text"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                placeholder="e.g., 30 years, 6 months, 7 days"
                className="input-field"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Gender *
              </label>
              <div className="flex space-x-4 mt-2">
                {['Male', 'Female', 'Other'].map((gender) => (
                  <label key={gender} className="flex items-center">
                    <input
                      type="radio"
                      name="gender"
                      checked={formData.gender === gender}
                      onChange={() => setFormData({ ...formData, gender: gender as any })}
                      className="mr-2"
                    />
                    <span>{gender}</span>
                  </label>
                ))}
              </div>
            </div>
            
            <div className="md:col-span-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Complaint (C/O) *
              </label>
              <textarea
                value={formData.complaint}
                onChange={(e) => setFormData({ ...formData, complaint: e.target.value })}
                className="input-field"
                rows={2}
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                House/Flat No.
              </label>
              <input
                type="text"
                value={formData.house}
                onChange={(e) => setFormData({ ...formData, house: e.target.value })}
                className="input-field"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Street
              </label>
              <input
                type="text"
                value={formData.street}
                onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                className="input-field"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Place *
              </label>
              <input
                type="text"
                value={formData.place}
                onChange={(e) => setFormData({ ...formData, place: e.target.value })}
                className="input-field"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number *
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="input-field"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Doctor *
              </label>
              <select
                value={formData.doctor_id}
                onChange={(e) => setFormData({ ...formData, doctor_id: parseInt(e.target.value) })}
                className="input-field"
                required
              >
                <option value="">Select Doctor</option>
                {doctors.map((doctor) => (
                  <option key={doctor.id} value={doctor.id}>
                    {doctor.name} ({doctor.code})
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Referred By
              </label>
              <input
                type="text"
                value={formData.referred_by}
                onChange={(e) => setFormData({ ...formData, referred_by: e.target.value })}
                className="input-field"
              />
            </div>
            
            {isIP && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Room
                </label>
                <input
                  type="text"
                  value={formData.room}
                  onChange={(e) => setFormData({ ...formData, room: e.target.value })}
                  className="input-field"
                />
              </div>
            )}
          </div>

          {/* Footer Section */}
          <div className="flex items-center justify-between pt-6 border-t">
            <div className="text-sm text-gray-600">
              Logged in as: <span className="font-semibold">Admin User</span>
            </div>
            
            <div className="flex space-x-3">
              <button
                type="button"
                onClick={handleDelete}
                className="btn-danger flex items-center"
              >
                <Trash2 size={20} className="mr-2" />
                Delete
              </button>
              
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="btn-secondary flex items-center"
              >
                <X size={20} className="mr-2" />
                Cancel
              </button>
              
              <button
                type="submit"
                disabled={isLoading}
                className="btn-primary flex items-center"
              >
                <Save size={20} className="mr-2" />
                {isLoading ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

export default PatientRegistration