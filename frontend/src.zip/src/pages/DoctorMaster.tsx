import { useState, useEffect } from 'react'
import axios from 'axios'
import { Save, Trash2, Plus, Edit, X } from 'lucide-react'
import toast from 'react-hot-toast'

interface Doctor {
  id?: number
  code: string
  name: string
  address: string
  qualification: string
  phone: string
  email: string
  specialty: string
  department: string
  op_validity: number
  booking_code: string
  max_tokens: number
  doctor_amount: number
  hospital_amount: number
  doctor_revisit: number
  hospital_revisit: number
  from_time: string
  to_time: string
  is_resigned: boolean
  is_discontinued: boolean
  resignation_date?: string
}

const DoctorMaster = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [formData, setFormData] = useState<Doctor>({
    code: '',
    name: '',
    address: '',
    qualification: '',
    phone: '',
    email: '',
    specialty: '',
    department: '',
    op_validity: 30,
    booking_code: '',
    max_tokens: 50,
    doctor_amount: 0,
    hospital_amount: 0,
    doctor_revisit: 0,
    hospital_revisit: 0,
    from_time: '09:00',
    to_time: '17:00',
    is_resigned: false,
    is_discontinued: false,
    resignation_date: ''
  })
  
  const [isEditing, setIsEditing] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    fetchDoctors()
  }, [])

  const fetchDoctors = async () => {
    try {
      const response = await axios.get('/doctors', {
        params: { active_only: false }
      })
      setDoctors(response.data)
    } catch (error) {
      toast.error('Failed to load doctors')
    }
  }

  const generateDoctorCode = () => {
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
    return `DR${random}`
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.code || !formData.name || !formData.specialty || !formData.department) {
      toast.error('Please fill required fields')
      return
    }
    
    setIsLoading(true)
    
    try {
      if (isEditing && formData.id) {
        await axios.put(`/api/doctors/${formData.id}`, formData)
        toast.success('Doctor updated successfully')
      } else {
        await axios.post('/doctors', {
          ...formData,
          code: formData.code || generateDoctorCode()
        })
        toast.success('Doctor added successfully')
      }
      
      resetForm()
      fetchDoctors()
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Operation failed')
    } finally {
      setIsLoading(false)
    }
  }

  const handleEdit = (doctor: Doctor) => {
    setFormData({
      ...doctor,
      resignation_date: doctor.resignation_date || ''
    })
    setIsEditing(true)
  }

  const handleDelete = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this doctor?')) return
    
    try {
      await axios.delete(`/api/doctors/${id}`)
      toast.success('Doctor deleted successfully')
      fetchDoctors()
    } catch (error) {
      toast.error('Failed to delete doctor')
    }
  }

  const resetForm = () => {
    setFormData({
      code: '',
      name: '',
      address: '',
      qualification: '',
      phone: '',
      email: '',
      specialty: '',
      department: '',
      op_validity: 30,
      booking_code: '',
      max_tokens: 50,
      doctor_amount: 0,
      hospital_amount: 0,
      doctor_revisit: 0,
      hospital_revisit: 0,
      from_time: '09:00',
      to_time: '17:00',
      is_resigned: false,
      is_discontinued: false,
      resignation_date: ''
    })
    setIsEditing(false)
  }

  const filteredDoctors = doctors.filter(doctor =>
    doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="max-w-7xl mx-auto">
      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Doctor Master</h1>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search doctors by name, code, or specialty..."
                className="input-field"
              />
            </div>
            <button
              onClick={resetForm}
              className="btn-secondary flex items-center"
            >
              <Plus size={20} className="mr-2" />
              Add New
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form Section */}
          <div className="lg:col-span-1">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                <h2 className="font-semibold text-lg">
                  {isEditing ? 'Edit Doctor' : 'Add New Doctor'}
                </h2>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Doctor Code *
                  </label>
                  <input
                    type="text"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    className="input-field"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="input-field"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <textarea
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="input-field"
                    rows={2}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Qualification
                  </label>
                  <input
                    type="text"
                    value={formData.qualification}
                    onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                    className="input-field"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="input-field"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="input-field"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Specialty/Speciality *
                  </label>
                  <input
                    type="text"
                    value={formData.specialty}
                    onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
                    className="input-field"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Department *
                  </label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="input-field"
                    required
                  >
                    <option value="">Select Department</option>
                    <option value="General Medicine">General Medicine</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="Orthopedics">Orthopedics</option>
                    <option value="Dermatology">Dermatology</option>
                    <option value="Neurology">Neurology</option>
                    <option value="ENT">ENT</option>
                    <option value="Ophthalmology">Ophthalmology</option>
                    <option value="Dentistry">Dentistry</option>
                  </select>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      OP Validity (days)
                    </label>
                    <input
                      type="number"
                      value={formData.op_validity}
                      onChange={(e) => setFormData({ ...formData, op_validity: parseInt(e.target.value) })}
                      className="input-field"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Booking Code
                    </label>
                    <input
                      type="text"
                      value={formData.booking_code}
                      onChange={(e) => setFormData({ ...formData, booking_code: e.target.value })}
                      className="input-field"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Maximum Tokens
                  </label>
                  <input
                    type="number"
                    value={formData.max_tokens}
                    onChange={(e) => setFormData({ ...formData, max_tokens: parseInt(e.target.value) })}
                    className="input-field"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Doctor Amount
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.doctor_amount}
                      onChange={(e) => setFormData({ ...formData, doctor_amount: parseFloat(e.target.value) })}
                      className="input-field"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Hospital Amount
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.hospital_amount}
                      onChange={(e) => setFormData({ ...formData, hospital_amount: parseFloat(e.target.value) })}
                      className="input-field"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Doctor Revisit
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.doctor_revisit}
                      onChange={(e) => setFormData({ ...formData, doctor_revisit: parseFloat(e.target.value) })}
                      className="input-field"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Hospital Revisit
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.hospital_revisit}
                      onChange={(e) => setFormData({ ...formData, hospital_revisit: parseFloat(e.target.value) })}
                      className="input-field"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      From Time
                    </label>
                    <input
                      type="time"
                      value={formData.from_time}
                      onChange={(e) => setFormData({ ...formData, from_time: e.target.value })}
                      className="input-field"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      To Time
                    </label>
                    <input
                      type="time"
                      value={formData.to_time}
                      onChange={(e) => setFormData({ ...formData, to_time: e.target.value })}
                      className="input-field"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.is_resigned}
                      onChange={(e) => setFormData({ ...formData, is_resigned: e.target.checked })}
                      className="mr-2"
                    />
                    <span>Resigned</span>
                  </label>
                  
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.is_discontinued}
                      onChange={(e) => setFormData({ ...formData, is_discontinued: e.target.checked })}
                      className="mr-2"
                    />
                    <span>Discontinued</span>
                  </label>
                  
                  {formData.is_resigned && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Resignation Date
                      </label>
                      <input
                        type="date"
                        value={formData.resignation_date}
                        onChange={(e) => setFormData({ ...formData, resignation_date: e.target.value })}
                        className="input-field"
                      />
                    </div>
                  )}
                </div>
                
                <div className="flex space-x-3 pt-4">
                  {isEditing && (
                    <button
                      type="button"
                      onClick={resetForm}
                      className="btn-secondary flex items-center"
                    >
                      <X size={20} className="mr-2" />
                      Cancel
                    </button>
                  )}
                  
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="btn-primary flex items-center flex-1"
                  >
                    <Save size={20} className="mr-2" />
                    {isLoading ? 'Saving...' : (isEditing ? 'Update' : 'Save')}
                  </button>
                </div>
              </div>
            </form>
          </div>

          {/* Doctor List (GridView) */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg border border-gray-200">
              <div className="p-4 border-b">
                <h3 className="font-semibold">Doctor List ({filteredDoctors.length})</h3>
              </div>
              
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Code
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Speciality
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Dept
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Phone
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredDoctors.map((doctor) => (
                      <tr key={doctor.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{doctor.code}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{doctor.name}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{doctor.specialty}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{doctor.department}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{doctor.phone}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            doctor.is_resigned 
                              ? 'bg-red-100 text-red-800'
                              : doctor.is_discontinued
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-green-100 text-green-800'
                          }`}>
                            {doctor.is_resigned ? 'Resigned' : doctor.is_discontinued ? 'Discontinued' : 'Active'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => handleEdit(doctor)}
                            className="text-primary-600 hover:text-primary-900 mr-4"
                          >
                            <Edit size={16} />
                          </button>
                          <button
                            onClick={() => doctor.id && handleDelete(doctor.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {filteredDoctors.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No doctors found
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DoctorMaster